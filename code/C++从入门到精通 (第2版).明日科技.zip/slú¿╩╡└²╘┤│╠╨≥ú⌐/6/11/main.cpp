#include<iostream>
using namespace std;
int subtration(int ,int );
int main()
{
	int i,j;
	cin >> i >> j;
	cout << subtration(i,j) <<endl;
	return 1;
}

int subtration(int a,int b)
{
	return a-b;
}