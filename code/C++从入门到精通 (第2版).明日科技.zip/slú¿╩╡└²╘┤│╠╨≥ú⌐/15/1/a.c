#include <iostream.h>
main()
{
	int a[10]={3,2,4,3,6,4,7,4,7,4},i,j,t,m;
 for(i=0;i<9;i++)
 {	m=i;
	 for(j=i+1;j<10;j++)
		 if(a[m]<a[j])
			 m=j;
	 t=a[i];a[i]=a[m];a[m]=t;
 }
 for(i=0;i<10;i++)
	 cout<<a[i]<<" ";
 return 0;
}
