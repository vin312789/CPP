#include <iostream>
using namespace std;
void main()
{
	int sum=0,i=1;
	do
	{
		sum=sum+i;
		i++;
	}while(i<=10);
	cout << "the result :" << sum << endl;
}

