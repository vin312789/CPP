#include <iostream>
using namespace std;
void main()
{
	int i=0,j=0;
	cout << "before do_while j=" << j << endl;
	do
	{
		j++;
	}while(i>1);
	cout << "after do_while j=" << j << endl;
}


