#include <iostream>
using namespace std;
void main()
{
	int i=0,j=0;
	cout << "before while j=" << j << endl;
	while(i>1)
	{
		j++;
	}
	cout << "after while j=" << j << endl;
}

