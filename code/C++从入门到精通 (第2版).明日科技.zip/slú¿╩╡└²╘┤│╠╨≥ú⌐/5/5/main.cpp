#include <iostream>
using namespace std;
void main()
{
	int sum=0;
	int i;
	for(i=1;i<=10;i++)//forѭ�����
		sum+=i;
    cout << "the result :" << sum << endl;
}


