#include <iostream>
using namespace std;
void main()
{
	int sum=0,i=1;
	while(i<=10)
	{
		sum=sum+i;
		i++;
	}
	cout << "the result :" << sum << endl;
}
