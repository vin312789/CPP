#include<iostream>
using namespace std;
void main()
{
	float i,j;
	int k;
	i=60.25;
	j=20.5;
	k=(int)i+(int)j; 	
	cout << k << endl;
}
