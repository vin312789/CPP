#include<iostream>
using namespace std;
void main()
{
	int a=0x40,b;
	b=a<<1;
	cout << b << endl;
}
