#include<iostream>
using namespace std;
void main()
{
	double result;
	char a='k';
	int b=10;
	float e=1.515;
	result=(a+b)-e;
	printf("%f\n",result);
}
