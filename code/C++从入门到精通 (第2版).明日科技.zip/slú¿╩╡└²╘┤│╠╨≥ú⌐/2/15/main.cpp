#include<iostream>
using namespace std;
int main()
{
	int i=123;
	printf("printf result :%d\n",123);
	cout << "cout result :" << i << endl;
	return 1;
}
