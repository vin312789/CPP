#include<iostream>
using namespace std;
void main()
{
	char c1,c2;
	c1='a';
	c2='b'; 
	int i1,i2;
	printf("%c,%d\n%c,%d",c1,c1,c2,c2);
}
