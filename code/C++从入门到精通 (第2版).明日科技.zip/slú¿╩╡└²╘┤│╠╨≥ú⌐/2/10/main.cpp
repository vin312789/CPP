#include<iostream>
void main()
{
	char *str="helloworld";
	printf("%s\n%10.5s\n%-10.2s\n%.3s",str,str,str,str);
}
