#include <iostream.h>
void main()
{
	int i=0;
cout << i<< endl;
	cout << "HelloWorld" <<endl;
}
