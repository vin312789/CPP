#include <iostream>
void main()
{
	float i=2998.453257845;
	double j=2998.453257845;
	printf("%e\n%15.2e\n%-10.3e\n%e",i,i,i,j);
}
