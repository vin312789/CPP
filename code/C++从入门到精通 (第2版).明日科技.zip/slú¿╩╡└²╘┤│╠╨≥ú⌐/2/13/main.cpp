#include <iostream.h>
int main()
{
	cout << "NiceWork!" << endl;
	return 1;
}
