/*
#include <iostream>
#include <iomanip>
using namespace std;
int avg(int a,int b);
void main()
{
	int iWidth,iLenght,iResult;
	i=10;
	j=30;
	iResult=avg(i,j);
	cout << iResult <<endl;
}

int avg(int a,int b)
{
	return (a+b)/2;
}

*/
#include <iostream>
#include <iomanip>
using namespace std;
int avg(int a,int b);
void main()
{
	int iWidth,iLenght,iResult;
	iWidth=10;
	iLenght=30;
	int (*pFun)(int,int);  //���庯��ָ��
	pFun=avg;

	iResult=(*pFun)(iWidth,iLenght);
	cout << iResult <<endl;
}
int avg(int a,int b)
{
	return (a+b)/2;
} 
