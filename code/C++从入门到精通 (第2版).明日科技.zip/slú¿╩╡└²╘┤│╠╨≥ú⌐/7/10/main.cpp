#include <iostream>
using namespace std;
void main()
{
	int a=100;
	int *p=&a;
	printf("%d\n",p);//��ȡ��ֵַ
}

