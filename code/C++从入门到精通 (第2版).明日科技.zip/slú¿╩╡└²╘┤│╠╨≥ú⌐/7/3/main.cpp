#include<iostream>
using namespace std;
void main()
{
	int i;
	char array[12];
	array[0]='a';
	array[1]='b';
	printf("%s\n",array);
}

