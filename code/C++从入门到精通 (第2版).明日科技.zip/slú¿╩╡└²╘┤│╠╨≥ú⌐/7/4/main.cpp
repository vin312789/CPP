#include<iostream>
using namespace std;
void main()
{
	int i;
	char array[12]={'H','E','L','L','O',' ','W','O','R','L','D'};
	for(i=0;i<12;i++)
		cout<<array[i];
	cout << endl;
}
