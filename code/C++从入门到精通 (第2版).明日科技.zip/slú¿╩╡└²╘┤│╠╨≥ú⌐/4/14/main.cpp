#include<iostream>
using namespace std;
int main()
{
	int i,j;
	cin >> i >> j;
	if(i>j)
		cout << "The Max:" << i << endl;
	else 
		cout << "The Max:" << j << endl;
}
