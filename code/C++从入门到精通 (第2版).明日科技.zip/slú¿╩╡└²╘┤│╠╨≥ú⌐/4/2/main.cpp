#include <iostream>
using namespace std;
void main()
{
	int iInput;
	cin >> iInput;
	if(iInput>90)
		cout << "It is Good" << endl;
	else
		cout << "It is not Good" << endl;
}
