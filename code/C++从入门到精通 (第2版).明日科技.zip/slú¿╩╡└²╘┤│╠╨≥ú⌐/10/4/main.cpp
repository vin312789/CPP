#include <iostream>
using namespace std;
#include "Person.h"
void main()
{
	CPerson p;
	p.ShowFrameMessage();
	p.ShowStartMessage();
	p.ShowFrameMessage();
}
