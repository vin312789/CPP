#include<iostream>
#include"Detach.h"
using namespace std;

void Output::Demo()							//���庯��
{
	cout<<"This is a  function!\n";
}
